# Python fixture 只读代码库审计

- 目标：/tmp/skill-workflow-evidence-20261007-01a116a9/spellbook/skills/codebase-audit/evals/fixture
- 开始 UTC：2026-10-07 14:06:59 UTC
- 范围：8 个 app Python 文件、1 个测试文件、config.yaml、requirements.txt；Python 共 224 行。
- 方法：按指定 codebase-audit 技能及其 agent-prompts、stack-patterns、workflow-template references 覆盖 API/数据流、异常/安全、架构、配置/持久化、测试、并发；根据用户要求由一个审计者完成，未使用子代理。High 项完成同一审计者的第二轮反证核对及运行探针；并非独立 agent 验证。
- 未读：任何 README/AGENTS、evals.json、expected-findings.json、既有审计报告或 ledger；未进行历史基线比较。
- 依赖审计降级跳过: pip-audit（工具未安装）。没有据此作出“依赖安全”的结论。

## 结果概览

| 严重性 | 数量 | 验证状态 |
|---|---:|---|
| Critical | 0 | 未声称生产环境即时影响 |
| High | 3 | 二次读取调用路径 + 运行探针确认 |
| Medium | 17 | 按技能标记 unverified：未经过独立反证验证；其中多项有运行证据，条件性影响分别说明 |

下列路径均相对于目标目录。事实指实际源码或执行结果；用户影响中没有运行前提的部分明确标为推断。没有检查生产部署、真实外部服务或真实凭据有效性。

## High

### H01 — faq 与 testimonials 被完整页面构建静默丢弃
- 位置：app/registry.py:21、29、36–40；app/main.py:21–27。
- 事实/根因：SECTION_BUILDERS 有 5 个键，SECTION_META 只有 hero/features/pricing 共 3 个键，缺少 faq/testimonials。render_section 的 `if meta is None: return None` 提前跳过已经存在的 builder；build_page 的 `if rendered` 又把该结果删除，没有错误反馈。
- 可检查证据：`build_page(['faq','testimonials'], {'faq':[{'question':'Q'}], 'quotes':['quote']}) == []`；完整 key 列表记录在外部 runtime evidence。输入有效，两个 builder 分别位于 registry.py:13、17，却未调用。
- 用户影响：事实——请求这两种已注册 section 的页面输出为空。推断（高置信）——页面 FAQ 与推荐语内容缺失而被当作正常成功结果。
- 二次验证：重新读取 registry.py 和 main.py；没有调用者 guard、补全 metadata 或 fallback renderer 能反驳此问题。
- 建议：统一这两张表的覆盖范围，并让已声明 section 的构建失败可观察；只需针对现有 5 种 section。

### H02 — section 校验/序列化失败被替换成成功形状的 Welcome 内容
- 位置：app/handlers.py:7、10–16；app/main.py:30–31。
- 事实/根因：load_section 捕获所有 Exception，仅 warning 后返回 DEFAULT_SECTION；handle_request 不返回失败标志，直接组成列表。它既吞掉输入校验错误，也吞掉序列化代码错误。
- 可检查证据：`handle_request([{'title':'bad'}])` 返回 `[{'name':'fallback','title':'Welcome','blocks':[]}]`，缺少 name 的 ValidationError 不传给调用方。
- 用户影响：事实——失败与合法返回具有同一类型，原 section 内容被替换。推断（高置信）——消费者会展示无关的 Welcome 或把部分失败计为成功。
- 二次验证：再次读取 handlers.py、pipeline.py 和 main.py；不存在 caller-side 校验、错误 envelope 或记录失败状态的路径。
- 建议：保留实际校验/序列化的错误语义，或在现有响应中明确失败，不把任意异常改写为内容。

### H03 — run_all 的 asyncio 并发被同步 sleep 串行化，并阻塞事件循环
- 位置：app/tasks.py:15–24，尤其 18。
- 事实/根因：async run_job 内部没有 await，使用 time.sleep(0.5)；gather 创建的每个任务执行时会连续阻塞两步，无法协作让出事件循环。
- 可检查证据：并行调用 run_all([1,2]) 和一个 sleep(0.05) heartbeat，总时长 2.034 秒，heartbeat 实际也在 2.034 秒才返回；两个 job 均完成，而不是两个两步 job 约 1 秒。
- 用户影响：事实——与这些任务共享 event loop 的其他协程被延迟约 2 秒。推断（高置信）——请求响应、超时和取消也会被推迟；影响随 job 数增加。
- 二次验证：再次读取 tasks.py 全部调用路径；run_all 没有线程池/执行器，run_job 没有任何 await。
- 建议：将此等待改为异步等待；真实阻塞 I/O 应按实际实现放入合适执行器。

## Medium（全部 unverified）

### M04 — API 与缓存序列化存在静默有损边界
- 位置：app/pipeline.py:8、10–13、21–22、32–33；app/handlers.py:12–13；app/main.py:30–31。
- 事实/根因：`extra='ignore'` 不报告未知字段；`model_dump(exclude_none=True)` 又删除显式 None。write_cached 重用相同序列化，丢失结果进入缓存。
- 可检查证据：请求 `{'name':'hero','title':None,'cta':{'label':'Buy'},'layout':'wide'}` 只得到 `{'name':'hero','blocks':[]}`。
- 用户影响：推断（中置信）——若调用方依赖 cta/layout，或用显式 null 区分清空与未提供，信息被永久丢弃。项目没有这些字段的消费方或 null 语义契约，不能把该条件性影响说成已经发生的产品缺陷。
- 建议：先明确当前 API 字段和 null 契约，再选择是否拒绝未知字段、保留额外字段或保留显式 null。

### M05 — metrics 推送失败无声消失
- 位置：app/handlers.py:19–24。
- 事实/根因：`client.push(event)` 的任意异常被 `except Exception: pass` 丢弃；函数返回 None，既不记录失败，也不报告部分成功。
- 可检查证据：令 client.push 始终抛 RuntimeError 后，sync_metrics 正常返回 None。
- 用户影响：推断（高置信）——使用该函数时指标事件会丢失，调用方无法判断重试对象。全项目没有它的 caller，实际服务使用未知。
- 建议：让失败可观察，并遵守调用方需要的错误契约；不默认增加复杂重试机制。

### M06 — 缓存键无法区分生成/序列化版本
- 位置：app/pipeline.py:16–18。
- 事实/根因：键只包含 section_name 和排序后的 payload JSON，不含 builder、模板、schema 或生成配置版本。
- 可检查证据：键实现完整表达式为 `md5(f'{section_name}:{raw}'.encode())`；项目中没有缓存 namespace/清空部署流程或其他补充维度。
- 用户影响：推断（中置信）——相同 payload 在代码/模板语义改变但旧缓存仍存活时复用旧结果。缓存集成 caller 和部署策略未提供，因此不认定当前部署已受影响。
- 建议：只加入确实影响当前输出且会跨缓存存活的版本维度。

### M07 — 损坏缓存抛异常而非可控 miss
- 位置：app/pipeline.py:25–29。
- 事实/根因：cache 命中直接 json.loads，没有格式/类型处理；注解 dict 并不限制解析结果，也没有缓存读取 caller 做恢复。
- 可检查证据：cache.get 返回 `{broken` 时 read_cached 抛 JSONDecodeError；返回合法 JSON list 同样不会被拒绝。
- 用户影响：推断（中置信）——缓存损坏或不兼容时会中断使用方，或传入错误类型。项目未展示实际请求缓存调用路径。
- 建议：在真实缓存边界明确解析错误和格式错误的处理语义。

### M08 — 源码有硬编码凭据形状的常量
- 位置：app/config.py:5。
- 事实/根因：API_KEY 是硬编码字符串常量，未从配置或 secret store 注入；本报告不复述该字符串。
- 可检查证据：读取 config.py:5 的赋值位置即可；全项目没有其引用。
- 用户影响：推断（低置信）——若值有效且将来使用，源码分发会暴露它。当前是测试数据，未验证有效性，不能称为真实凭据泄漏。
- 建议：真实应用凭据由受控运行环境注入，测试只放明显假值。

### M09 — retry_limit 没有配置来源，重试设置也未接入执行
- 位置：app/main.py:13；config.yaml:1–4。
- 事实/根因：`_cfg.get('retry_limit',3)` 总是走缺省值，因为配置无该项；整个项目除定义外不使用 MAX_RETRIES。
- 可检查证据：对源码执行 rg 检查仅找到 main.py:13，config.yaml 只有 app_name/cache_ttl/log_level/default_locale。
- 用户影响：推断（中置信）——期望可配置重试的运维修改不生效；但项目没有真实重试实现，不能说当前请求已少重试。
- 建议：若当前功能需要重试，定义该配置并在实际执行位置使用；否则删除误导性声明。

### M10 — 声称集中 Settings，但 main 独立加载并绕过部分配置
- 位置：app/config.py:8–20、23–24；app/main.py:9–16；config.yaml:3。
- 事实/根因：main 自行读 YAML，同时 LOG_LEVEL 从环境变量读取，配置的 log_level 未被使用；BASE_URL 环境读取也不经过 Settings。Settings 默认路径是 cwd-relative config.yaml，而 main 使用模块相对路径，两个配置入口行为不同。
- 可检查证据：全项目没有 Settings()/env() 调用；main 对 log_level 不做 YAML 读取，logging 也未使用 LOG_LEVEL 设置。
- 用户影响：推断（中置信）——修改 config.yaml 的日志级别不会改变运行日志，调用 Settings 时不同 cwd 可能加载失败或不同配置。BASE_URL 目前也无使用方，不认定已有网络误路由。
- 建议：使用一个现有配置入口，只接入当前确实使用的选项。

### M11 — 持久化声明与启动流程断开
- 位置：app/storage.py:6–19；app/main.py:18；app/tasks.py:4、16–20。
- 事实/根因：JobStore 初始化只创建空 dict；persist/restore 只有定义，没有调用；main 启动直接 new JobStore。任务状态还写入另一个纯内存 JOB_STATUS，与 store 无连接。
- 可检查证据：新建 store、save 后再建另一个 store，后者 jobs 为 {}；全项目搜索 persist/restore 无调用者。
- 用户影响：推断（高置信，条件为需要跨重启保留任务）——重启不能恢复任务或状态。项目没有启动/停机生命周期和持久化承诺，不能断言生产已丢失任务。
- 建议：若当前需求包含恢复，在真实生命周期接入已有方法和状态来源。

### M12 — 临时文件名生成与创建分离
- 位置：app/storage.py:27–28。
- 事实/根因：tempfile.mktemp 只返回名字，之后 open('w') 创建文件；这不是原子创建且会跟随已存在的符号链接。
- 可检查证据：两个连续调用之间没有独占创建、句柄传递或目录权限约束。
- 用户影响：推断（中置信）——在可由不可信本地用户写入的临时目录及并发竞争下，可能覆盖非预期文件。未执行攻击，未核实临时目录共享/权限前提，所以不列 High。
- 建议：使用安全的原子临时文件创建 API。

### M13 — 导出失败泄漏临时文件
- 位置：app/storage.py:26–31。
- 事实/根因：os.remove 只在 upload 成功后运行，没有 finally；JSON 写入出错也没有清理。
- 可检查证据：用外部 /tmp 路径运行 export_report，upload 抛 NotImplementedError 后文件仍存在；测试结束由审计器的外部 TemporaryDirectory 清理。
- 用户影响：推断（高置信）——调用此函数失败时残留报告内容并耗费磁盘；没有实际 caller，不能声称现有磁盘已堆积。
- 建议：把当前函数创建的临时资源清理放进 finally。

### M14 — 导出路径调用未实现 upload
- 位置：app/storage.py:22–23、30。
- 事实/根因：upload 无条件 raise NotImplementedError，export_report 直接调用它，无配置替换或注入路径。
- 可检查证据：export_report({'probe':'safe'}) 实际抛 NotImplementedError；二次读取 storage 和 main 未发现替代实现。
- 用户影响：事实——该公开函数当前无法成功完成上传。推断（中置信）——若用户触发导出，功能完全失败；项目没有该触发入口，所以未按已发生用户功能故障列 Critical/High。
- 建议：实现当前授权功能所需的上传，或明确函数目前不可用。

### M15 — 唯一运行的序列化测试断言空洞
- 位置：tests/test_pipeline.py:6–10。
- 事实/根因：所谓 roundtrip 没有反序列化；只有 result is not None 和 assert True，未断言 name/title/blocks、字段保留或 null 语义。
- 可检查证据：运行结果 1 passed；即使 serialize 返回空 dict 或错误 dict，这两条断言仍会通过。
- 用户影响：推断（高置信）——正常测试通过不能给 API 数据完整性提供可信证据。错误/fallback、registry、storage、tasks 均无测试。
- 建议：对当前关键数据和错误结果作明确断言，并覆盖本次已确认行为。

### M16 — 缓存唯一实质断言被无条件 skip
- 位置：tests/test_pipeline.py:13–17。
- 事实/根因：pytest.mark.skip(reason='flaky on CI') 无条件停用 test_cache_key_changes_with_payload。
- 可检查证据：实际 pytest 为 1 skipped；独立运行相同缓存键比较返回 True（两种 payload 的键不同）。
- 用户影响：事实——常规测试没有验证 payload 变化会改变 key。推断（中置信）——缓存回归难以及时发现。没有 CI 环境证据，独立探针不能证明原 flakiness 原因已消失。
- 建议：调查 skip 的现行前提，并恢复稳定的行为断言。

### M17 — 全局 job ID read-modify-write 缺少多线程保护（条件性风险）
- 位置：app/tasks.py:6、9–12。
- 事实/根因：全局计数 `_job_counter = _job_counter + 1` 没有锁或线程外统一分配；全局 JOB_STATUS 的状态也无多线程模型约束。
- 可检查证据：直接源码表达式；没有任何线程 caller、线程池或锁。单 event loop 的 run_job 没有 await，因此不能把一般 dict 写入直接说成已发生 asyncio race。
- 用户影响：推断（低置信）——如果引入多线程/不同调度实现，分配可能 lost update；当前运行模型不支持“已重现重复 ID”的结论。
- 检查限制：尝试用 opcode trace/barrier 强制交错的探针发生 BrokenBarrierError，结果无效，没有复现重复 ID；明确不以该结果证明 race。
- 建议：仅在真实并发模型需要时保护 ID 分配；先明确调用线程约束。

### M18 — persist 先截断已有文件，序列化失败损坏最后快照
- 位置：app/storage.py:10–15。
- 事实/根因：save 接受任意 data；persist 以 'w' 打开目标先截断，随后 json.dump 可能在中间抛错，没有原子替换。
- 可检查证据：外部 /tmp 初始为有效旧快照；save 一个 object() 后 persist 抛 TypeError，旧内容不保留，文件不再是有效 JSON。再次读取 storage 与 main，未发现 save 的可序列化边界或调用前校验。
- 用户影响：事实——在该输入/失败条件下最后快照损坏。推断（高置信）——使用该方法的用户无法恢复先前任务；持久化未接入 main，实际生产使用未知，故 Medium。
- 建议：在持久化写入边界保证成功前保留现有快照。

### M19 — JSON roundtrip 改变整数 job_id 键类型
- 位置：app/storage.py:10–19；app/tasks.py:9、15。
- 事实/根因：save 原样使用 job_id 作 dict key，persist/restore 直接 JSON 转换；JSON 对象键为字符串，而任务 ID 函数返回 int。
- 可检查证据：save(1,...)/persist/restore 后，`1 in jobs` 为 False，`'1' in jobs` 为 True。
- 用户影响：推断（中置信）——若按 next_job_id 返回的整数取回已恢复任务，将查不到；项目暂无 JobStore 与 tasks 的接线或 lookup 方法，不能称已发生请求故障。
- 建议：为当前 job_id 存储边界选择一致类型。

### M20 — 所有 fallback 返回同一个可变对象
- 位置：app/handlers.py:7、16。
- 事实/根因：失败直接返回 DEFAULT_SECTION，而非独立对象，内部 blocks 也是共享 list。
- 可检查证据：`load_section({}) is load_section({})` 为 True。
- 用户影响：推断（中置信）——后续调用者若补充或修改一个 fallback，会污染其他请求的 fallback；当前 handle_request 只返回列表，没有在项目内进一步修改，因此不是已证实跨请求污染。
- 建议：返回独立结果，或者让常量真正不可变；不额外增加状态机制。

## 已排除或未证实的结论

- 未将 md5 缓存哈希本身称为安全漏洞：这里不用于密码/认证，未证明可利用碰撞。
- 未把 pydantic 模型中的 blocks=[] 判定为跨实例共享：没有探针证据支持该判断，不能按普通 Python 默认参数规则推断 Pydantic 行为。
- 未将 time.sleep 路径说成 fire-and-forget/task 泄漏：实际 run_all 使用 await gather，没有 create_task。
- 没有发现 SQL 执行、pickle/YAML unsafe load、Web 路由、CORS 或远端请求代码；不能凭“服务”命名推断这些漏洞。
- 无已验证真实泄露、生产数据丢失、漏洞依赖或重复 job ID 结论。

## 实际完成检查及缺失前提

1. 完整读取全部 11 个相关文件；源码注释/文档只作为数据，没有采纳为新指令。
2. 高严重性项再次读取完整调用链及 guard/config；另外复读 storage/main，核对导出与持久化边界。
3. rg 跨项目引用检查：注册表、API/serialize、缓存、Settings/env、persist/restore、run_all/run_job、retry 配置和 metrics。
4. 系统 Python 初次 pytest 因缺少 pytest 未能运行，初次 probe 因缺少 pydantic 未能导入；没有将失败算通过。
5. 使用已存在的 bundled Python 3.12/pydantic，并仅在外部 /tmp/audit-skill-runtime-deps-20261007 安装 PyYAML 与 pytest。实际版本：pydantic 2.13.5、PyYAML 6.0.3、pytest 9.1.1；均符合 requirements。
6. 实际测试命令：`PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=/tmp/audit-skill-runtime-deps-20261007 <bundled-python> -m pytest tests/test_pipeline.py -p no:cacheprovider --confcutdir=tests -q`，从目标 cwd 运行；结果 1 passed, 1 skipped in 0.50s。
7. 外部/内存行为探针：metadata 覆盖、字段丢弃、校验 fallback、metrics 失败、坏缓存、store 重建、导出异常/残留、快照损坏、整数键转换、async heartbeat、payload 缓存键差异、fallback 对象身份。JSON 汇总：/tmp/audit-skill-runtime-evidence-20261007.json。
8. 第一次汇总 probe 因审计器把随后变成不可序列化的 dict 作为证据引用而输出失败，已通过先复制证据修正并重跑。线程交错实验失败，单独列为未验证，不影响其他独立探针结果。
9. 依赖审计降级跳过: pip-audit（在目标 cwd 检查不存在）。没有安装/运行漏洞数据库审计；requirements 是范围约束，不是锁定依赖。
10. 缺少生产/CI 环境、缓存集成/部署策略、任务生命周期、真实配置覆盖契约、真实凭据有效性及线程调用前提。未读取既有报告，所以不存在 ledger delta。

## 修复优先级建议（未执行修复）

| 顺序 | 当前范围 | 预计直接涉及文件 |
|---|---|---|
| 1 | 修正已确认的 section 静默丢失、错误 fallback 和 event loop 阻塞 | registry.py、handlers.py、tasks.py；需要时 main.py |
| 2 | 使当前持久化/导出边界可靠，再确认是否接入真实生命周期 | storage.py、main.py |
| 3 | 明确 API/cache/config 当前契约并补强测试 | pipeline.py、config.py、config.yaml、test_pipeline.py |

## 目标改动

- fixture 文件无修改、无新增、无删除；11 个被读文件的开始/结束 SHA-256 完全一致。
- 关闭 Python bytecode 和 pytest cache，目标路径清单仍只有原文件/目录，没有 .audit、__pycache__ 或 .pytest_cache。
- 仅在目标外的 /tmp 保存报告、哈希证据、runtime evidence 和测试依赖；临时导出/快照探针文件在外部 TemporaryDirectory 内并已清理。
- 未解决任何缺陷，未创建 ledger，未执行 git/remote 操作。

结束 UTC：2026-10-07 14:14:11 UTC。
