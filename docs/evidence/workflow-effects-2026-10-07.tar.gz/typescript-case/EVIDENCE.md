# TypeScript workflow evidence

Start UTC: 2026-10-07 14:09:43 UTC

Skill read: `/tmp/skill-workflow-evidence-20261007-01a116a9/install/codex/skills/typescript-project/SKILL.md`.

Activation evidence: Bun runtime/test runner, ESM, strict TypeScript, and Zod runtime validation were selected from the skill. These selections alone do not establish a functional outcome. The task restricts scope to an in-memory TODO API; unnecessary layers, LLM integration, credentials, database, and extra tooling are omitted.

Model call cost: unknown. Token usage: unknown. External user outcomes: not measured.

Setup note: first setup command did not execute because its target work directory did not yet exist; created the directory and repeated setup successfully.

End UTC (functional checks complete): 2026-10-07 14:12:21 UTC

## Installed versions

- Bun: 1.3.14 (0d9b296a)
- TypeScript: 7.0.2 (`bunx --no-install tsc --version`)
- Zod: 4.6.5
- @types/bun: 1.4.2
- `bun install`: exit 0, 7 packages installed; lockfile saved.

## Completed CLI verification

`bun test`: exit 0; 5 pass, 0 fail, 79 expect() calls, 1 test file.

- creates, trims, lists, and deletes a todo
- accepts inclusive trimmed title lengths 1 and 100
- invalid input never inserts or changes existing state (malformed/empty JSON, null, array, missing title, wrong types, blank title, length 101)
- unknown IDs/routes return 404 and preserve state
- wrong methods return 405 with Allow and preserve state

`bun run typecheck`: exit 0 (`tsc --noEmit`).

A Python CLI smoke check launched `src/index.ts` using Bun in a subprocess whose entire environment was `{PORT: "0"}`. No external API credential variables were provided. The actual server listened at `http://localhost:54346/`, proving PORT configuration is used. Actual HTTP outcomes:

```
GET /todos: 200 (empty list)
POST /todos: 201 (title trimmed to CLI smoke)
GET /todos: 200 (created item present)
POST /todos: 400 (malformed JSON)
POST /todos: 400 (blank title)
PUT /todos: 405
DELETE /todos/missing: 404
GET /missing: 404
GET /todos: 200 (original item unchanged)
DELETE /todos/2983473e-804d-467b-8383-a7ad36d0d187: 204 (empty body)
GET /todos: 200 (empty list after delete)
DELETE /todos/2983473e-804d-467b-8383-a7ad36d0d187: 404
```

Smoke command exit: 0. Server terminated and waited for; no background server remains.

## Actual project files (excluding installed node_modules)

```
EVIDENCE.md
bun.lock
package.json
src/api.ts
src/index.ts
tests/api.test.ts
tsconfig.json
```

Verified outcome: this scoped TODO API works through its handler and actual HTTP server without external credentials. This is one model implementation case, not evidence of a measured productivity percentage or general superiority of the skill. No git commit or push was performed. No other project or user configuration was edited.
