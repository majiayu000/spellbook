import fetch from "./api";

const server = Bun.serve({ port: Number(Bun.env.PORT ?? "3000"), fetch });
console.log(`TODO API listening at ${server.url}`);
