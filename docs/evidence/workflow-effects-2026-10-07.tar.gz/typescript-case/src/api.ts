import { z } from "zod";

const titleSchema = z.object({ title: z.string().trim().min(1).max(100) });
type Todo = { id: string; title: string };
const todos = new Map<string, Todo>();

function error(message: string, status: number, allow?: string): Response {
  return Response.json({ error: message }, {
    status,
    headers: allow ? { Allow: allow } : undefined,
  });
}

export default async function fetch(request: Request): Promise<Response> {
  const path = new URL(request.url).pathname;
  if (path === "/todos") {
    if (request.method === "GET") {
      return Response.json([...todos.values()]);
    }
    if (request.method !== "POST") {
      return error("Method not allowed", 405, "GET, POST");
    }

    let body: unknown;
    try {
      body = await request.json();
    } catch {
      return error("Invalid JSON", 400);
    }
    const input = titleSchema.safeParse(body);
    if (!input.success) {
      return error("title must contain 1-100 characters after trimming", 400);
    }
    const todo: Todo = { id: crypto.randomUUID(), title: input.data.title };
    todos.set(todo.id, todo);
    return Response.json(todo, { status: 201 });
  }

  const match = /^\/todos\/([^/]+)$/.exec(path);
  const id = match?.[1];
  if (id !== undefined) {
    if (request.method !== "DELETE") {
      return error("Method not allowed", 405, "DELETE");
    }
    if (!todos.delete(id)) {
      return error("Todo not found", 404);
    }
    return new Response(null, { status: 204 });
  }
  return error("Route not found", 404);
}
