import { beforeEach, describe, expect, test } from "bun:test";
import handle from "../src/api";

type Todo = { id: string; title: string };
const request = (path: string, method = "GET", body?: string) =>
  handle(new Request(`http://localhost${path}`, { method, body }));
const list = async (): Promise<Todo[]> => (await request("/todos")).json();

beforeEach(async () => {
  for (const todo of await list()) {
    await request(`/todos/${todo.id}`, "DELETE");
  }
});

describe("TODO HTTP API", () => {
  test("creates, trims, lists, and deletes a todo", async () => {
    const created = await request("/todos", "POST", JSON.stringify({ title: "  Buy milk  " }));
    expect(created.status).toBe(201);
    const todo: Todo = await created.json();
    expect(todo.id).toBeString();
    expect(todo.title).toBe("Buy milk");
    const listed = await request("/todos");
    expect(listed.status).toBe(200);
    expect(await listed.json()).toEqual([todo]);
    const deleted = await request(`/todos/${todo.id}`, "DELETE");
    expect(deleted.status).toBe(204);
    expect(await deleted.text()).toBe("");
    expect(await list()).toEqual([]);
    expect((await request(`/todos/${todo.id}`, "DELETE")).status).toBe(404);
  });

  test("accepts the inclusive trimmed title length boundaries", async () => {
    for (const title of ["a", "a".repeat(100)]) {
      const response = await request("/todos", "POST", JSON.stringify({ title: `  ${title}  ` }));
      expect(response.status).toBe(201);
      expect((await response.json()).title).toBe(title);
    }
    expect(await list()).toHaveLength(2);
  });

  test("invalid input never inserts or changes existing state", async () => {
    await request("/todos", "POST", JSON.stringify({ title: "Keep me" }));
    const original = await list();
    const invalidBodies = ["{", "", "null", "[]", "{}", '{"title":1}', '{"title":null}',
      JSON.stringify({ title: "" }), JSON.stringify({ title: "   " }),
      JSON.stringify({ title: "a".repeat(101) })];
    for (const body of invalidBodies) {
      const response = await request("/todos", "POST", body);
      expect(response.status).toBe(400);
      expect((await response.json()).error).toBeString();
      expect(await list()).toEqual(original);
    }
  });

  test("unknown IDs and routes retain 404 and leave state unchanged", async () => {
    await request("/todos", "POST", '{"title":"Keep me"}');
    const original = await list();
    const routes: [string, string][] = [["/todos/missing", "DELETE"], ["/missing", "GET"],
      ["/missing", "POST"], ["/todos/a/b", "DELETE"]];
    for (const [path, method] of routes) {
      const response = await request(path, method);
      expect(response.status).toBe(404);
      expect((await response.json()).error).toBeString();
      expect(await list()).toEqual(original);
    }
  });

  test("wrong methods retain 405, expose Allow, and do not mutate state", async () => {
    const created: Todo = await (await request("/todos", "POST", '{"title":"Keep me"}')).json();
    for (const method of ["PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"]) {
      const response = await request("/todos", method);
      expect(response.status).toBe(405);
      expect(response.headers.get("Allow")).toBe("GET, POST");
    }
    for (const method of ["GET", "POST", "PUT", "PATCH", "HEAD", "OPTIONS"]) {
      const response = await request(`/todos/${created.id}`, method);
      expect(response.status).toBe(405);
      expect(response.headers.get("Allow")).toBe("DELETE");
    }
    expect(await list()).toEqual([created]);
  });
});
